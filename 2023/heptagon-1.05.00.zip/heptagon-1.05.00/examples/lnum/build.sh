bzreax lnum_simple.ept tasks -a sS:d={P:D} -s
